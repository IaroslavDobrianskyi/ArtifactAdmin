﻿using System;
using NUnit.Framework;

namespace $safeprojectname$
{
    [TestFixture]
    public class MyTypeShould
    {
        [Test]
        public void DoSomething() {}
    }
}